
from django.contrib import admin

from .models import Pedido

admin.site.register(Pedido)



from django.contrib import admin

from .models import Cadastrar

admin.site.register(Cadastrar)



from django.contrib import admin

from .models import Auth
admin.site.register(Auth)




