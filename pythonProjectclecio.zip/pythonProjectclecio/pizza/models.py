
from django.db import models


class Cliente(models.Model):
    nome = models.CharField(max_length=100)
    email = models.TextField(null=True)


class Pedido(models.Model):
    endereco = models.TextField(null=True)
    telefone = models.CharField(max_length=20)
    total = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f'Pedido #{self.pk}'
    
class ItemPedido(models.Model):
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE)
    nome = models.CharField(max_length=100)
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    quantidade = models.DecimalField(max_digits=10, decimal_places=2)
    def __str__(self):
        return self.nome

class Cadastrar(models.Model):
    nome = models.CharField(max_length=100, null=True)
    email = models.EmailField(null=True)
    senha = models.CharField(max_length = 10, null=True)


    def __str__(self):
        return self.nome


class Auth(models.Model):
    username = models.CharField(max_length=30, unique=True)
    password = models.CharField(max_length=128)

    def __str__(self):
        return self.username,


