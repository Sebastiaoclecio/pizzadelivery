from django.urls import path
from . import views
from .views import processar_pedido

urlpatterns = [
    path('cadastro/', views.cadastrar, name='cadastrar'),
    path('auth/', views.auth, name='auth'),
    path('inicio/',views.inicio, name='inicio'),
    path('processar_pedido/',views.processar_pedido, name='processar_pedido'),
    path('user/', views.user, name='user'), 
]



