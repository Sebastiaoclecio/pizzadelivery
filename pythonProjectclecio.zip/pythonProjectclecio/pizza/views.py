from django.http import HttpResponse
from django.shortcuts import render ,redirect
from .models import  Pedido, ItemPedido, Cadastrar, Auth
from django.contrib.auth.models import User
from django.contrib.auth import authenticate 
from django.contrib.auth import login as auth_django


def cadastrar(request):
    cadastros = Cadastrar.objects.all()
    if request.method == "GET":
       return render(request, 'cadastrar/cadastrar.html', {'cadastros': cadastros})
    else:
       username = request.POST.get('username')
       email = request.POST.get('email')
       password = request.POST.get('password')

       user = User.objects.filter(username=username).first()
       if user:
            return HttpResponse("ja existe um usuario com esse username")
       else:
           user = User.objects.create_user(username=username, email=email , password=password)
           user.save()
    
    return redirect("processar_pedido")
      


def auth(request):
    if request.method == "GET":
        return render(request, 'auth/auth.html')
    else:
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        
        if user:
            auth_django(request, user)  
            return redirect ('processar_pedido')
        
        else:
              
              return HttpResponse("Nome de usuário ou senha inválidos!")



def inicio(request):
    return render(request, 'inicio/inicio.html')
    
def user (request):
    user = User.objects.all()
    return render(request, "user/user.html")

 
def processar_pedido(request):
    return render(request, 'processar_pedido/processar_pedido.html')
